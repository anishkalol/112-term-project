from cmu_112_graphics import *
import random
from PIL import Image

# imported files
from terrain import *
from dinosaurSprite import *
from cacti import *
from birds import *
from coins import *
from ui import *

##### sources #####
# all sprites from: https://www.spriters-resource.com/browser_games/googledinosaurrungame/sheet/78171/
# terrain gen: https://www.cs.cmu.edu/~112/notes/student-tp-guides/Terrain.pdf 
# ^ used to figure out which algo is appropriate for 1d hill gen

def almostEqual(x, y):
    return abs(x - y) <= 1

def appStarted(app):
    app.height = 600
    app.width = 800
    
    ##### terrain gen #####
    app.iterations = 7
    app.numPoints = 2**(app.iterations + 1)
    app.terrainHeight = 400
    app.randomRange = 100
    app.points = midpointDisplacement(app.iterations, [[0, app.terrainHeight], [app.width, app.terrainHeight]], app.randomRange)
    
    # holes
    app.randomHolePoint = 0

    ##### side scrolling #####
    app.scrollX = 0
    app.scrollY = 0
    app.timerDelay = 50

    ##### dino sprite #####
    dinoSprite = 'dinosaursprite.png'
    spriteStripDino = app.loadImage(dinoSprite)
    app.dinoSprite = []
    
    for i in range(2):
        # cropping each sprite movement
        sprite = spriteStripDino.crop((i*53, 10, 54 + 45*i, 90))
        app.dinoSprite.append(sprite)
    app.spriteCounterDino = 0

    app.dinosaurX = 100
    app.dinosaurY = app.points[0][1]

    # vars for jump/fall
    app.isJumping = False
    # app.vi = 8.5 # initial velocity
    # app.vt = app.vi # changing vel
    app.inAir = False
    app.gravity = 1
    # app.dy = 0
    app.velocity = -100
    app.jumpCount = 0
    app.currDinoY = 0
    app.prevTime = 0
    app.currTime = 0
    # app.acceleration = 5
    # app.inAir = False
    # app.numJumps = 0
    # app.timerJumpCount = 0

    ##### cacti #####
    # cactus images
    app.cactus1 = app.loadImage('cactus1.png')
    app.cactus2 = app.loadImage('cactus2.png')
    app.cactus3 = app.loadImage('cactus3.png')
    app.cacti = [app.cactus1, app.cactus2, app.cactus3]
    
    # list of cactus spawn places
    app.cactusMap = [[0,0]]
    # app.cactusPoint = 0
    app.randomCactus = random.randint(0, 2) # picks random cactus img

    ##### bird enemies #####
    birdsSprite = 'birds.png'
    spriteStripBirds = app.loadImage(birdsSprite)
    app.birdsSprite = []
    # list of bird spawn places
    app.birdMap = [[0,0]]
    # app.birdPoint = 0
    app.birdHeight = 0
   
    # sprite
    for i in range(2):
        sprite = spriteStripBirds.crop((55*i, 0, 55*i + 55, 51))
        app.birdsSprite.append(sprite)
    app.spriteCounterBirds = 0

    ##### coins #####
    coinSprite = 'coins.png'
    spriteStripCoins = app.loadImage(coinSprite)
    app.coinSprite = []
    app.coinMap = [[0,0]]
    app.coinPoint = 0
    app.score = 0
    
    # sprite
    for i in range(6):
        sprite = spriteStripCoins.crop((64*i, 0, 64*i + 60, 73))
        app.coinSprite.append(sprite)
    app.spriteCounterCoins = 0

    ##### game over #####
    app.isGameOver = False

def timerFired(app):
    if app.isGameOver:
        return
    else:
        # dino running movement
        if app.isJumping == False:
            app.spriteCounterDino = (1 + app.spriteCounterDino) % len(app.dinoSprite)

        # bird flying movement
        app.spriteCounterBirds = (1 + app.spriteCounterBirds) % len(app.birdsSprite)

        # coin movement
        app.spriteCounterCoins = (1 + app.spriteCounterCoins) % len(app.coinSprite)
        
        app.scrollX += 5
        app.scrollY += 5

        # generating infinite terrain
        if app.scrollX % app.width == app.width // 8:
            x0 = app.points[-1][0] + 1
            x1 = app.points[-1][0] + app.width + 1
            app.points += midpointDisplacement(app.iterations, [[x0, app.terrainHeight], [x1, app.terrainHeight]], app.randomRange)
            # making holes
            app.randomHolePoint = random.randint(app.width//2, len(app.points) - 20)
            for i in range(app.randomHolePoint, app.randomHolePoint + 20):
                app.points[i][1] = app.height//0.2
            if app.dinosaurY == app.height//0.2:
                app.isGameOver = True

            # making cacti
            cactusPoint = random.randint(app.width//3, len(app.points) - 1)
            if app.points[cactusPoint][1] != app.height//0.2: # so no cacti are placed in holes
                # if app.points[cactusPoint][0] >= 1000:
                    app.points[cactusPoint][1] = app.points[cactusPoint][1] - 5
                    app.cactusMap.append([app.points[cactusPoint][0], app.points[cactusPoint][1]])

            # making birds
            birdPoint = random.randint(app.width//3, len(app.points) - 1)
            if abs(birdPoint - cactusPoint) > 20:
                birdHeight = app.points[birdPoint][1] - 150 # finding height of where bird should spawn
                app.birdMap.append([app.points[birdPoint][0], birdHeight])

            # making coins
            coinPoint = random.randint(app.width//3, len(app.points) - 1)
            if abs(coinPoint - cactusPoint) > 20: # checking for overlap b/w coins and cacti
                # if app.points[coinPoint][0] >= 1000:    
                    app.points[coinPoint][1] = app.points[coinPoint][1] - 5
                    app.coinMap.append([app.points[coinPoint][0], app.points[coinPoint][1]])
        
        # slicing off points that are already drawn
        # and have moved off the canvas
        if app.scrollX % app.width == 0:
            for i in range(app.numPoints):
                app.points.pop(0)

        # walking on terrain
        for i in range(len(app.points)):
            if almostEqual(app.dinosaurX, app.points[i][0] - app.scrollX):              
                    app.dinosaurY = app.points[i][1]
        
        # checking for cacti collision
        if 0 < len(app.cactusMap):
            if len(app.cactusMap) > 1 and app.cactusMap[0] == [0,0]:
                app.cactusMap.pop(0)
            if abs(app.dinosaurX + app.scrollX - app.cactusMap[0][0]) < 10:
                if abs(app.dinosaurY - app.cactusMap[0][1]) < 10:
                    app.isGameOver = True
                    print("u lost lmaoooo")
                    # print(app.dinosaurX + app.scrollX, app.dinosaurY, app.cactusMap)
                    # print(abs(app.dinosaurY - app.cactusMap[0][1]) < 10 and abs(app.dinosaurX + app.scrollX - app.cactusMap[0][0]) < 10)
                    if app.scrollX % app.cactusMap[0][0] == 0:
                        app.cactusMap.pop(0)
        print(app.dinosaurX + app.scrollX, app.dinosaurY, app.cactusMap)
        print(abs(app.dinosaurY - app.cactusMap[0][1]) < 10 and abs(app.dinosaurX + app.scrollX - app.cactusMap[0][0]) < 10)
        
        # collecting coins
        if 0 < len(app.coinMap):
            if len(app.coinMap) > 1 and app.coinMap[0] == [0,0]:
                app.coinMap.pop(0)
            if abs(app.dinosaurX + app.scrollX - app.coinMap[0][0]) < 30:
                print("YAY")
                app.coinMap.pop(0)
                app.score += 1
        # print(app.dinosaurX + app.scrollX, app.coinMap)
    
        # divebombssss
        if 0 < len(app.birdMap):
            if len(app.birdMap) > 1 and app.birdMap[0] == [-25,75]:
                app.birdMap.pop(0)
            if abs(app.dinosaurX + app.scrollX - app.birdMap[0][0]) < 150:
                app.birdMap[0][0] -= 5
                app.birdMap[0][1] += 15
                for i in range(len(app.points) - 1):
                    if app.birdMap[0][1] > app.points[i][1]:
                        app.birdMap[0][1] -= 15
                if (abs(app.dinosaurX + app.scrollX - app.birdMap[0][0]) < 20 and
                    abs(app.dinosaurY - app.birdMap[0][1]) < 20):
                    app.isGameOver = True
                # if app.scrollX % app.birdMap[0][0]:
                    # app.birdMap.pop(0)
        # print(app.dinosaurX + app.scrollX, app.birdMap)
        
        # jump/fall movement
        if app.isJumping:
            app.dinosaurY = app.currDinoY
            if app.jumpCount < 12:
                app.dinosaurY -= 10
                app.jumpCount += 1
            elif 24 <= app.jumpCount:
                app.dinosaurY += 10
                app.jumpCount += 1
            for i in range(len(app.points)):
                if almostEqual(app.dinosaurY, app.points[i][1]) and app.jumpCount == 24:
                    app.dinosaurY = app.points[i][1]
                    app.isJumping = False
                    app.jumpCount = 0
            app.isJumping = False   
            app.jumpCount = 0

def keyPressed(app, event):
    if app.isGameOver == False:
        if event.key == "Space" or event.key == "Up":
            if app.isJumping == False:
                app.currDinoY = app.dinosaurY
                app.isJumping = True
    elif event.key == "r":
        appStarted(app)

def redrawAll(app, canvas):
    # drawStartGame(app, canvas)
    drawTerrain(app, canvas)
    drawCactus(app, canvas)
    drawBirdsSprite(app, canvas)
    drawCoins(app, canvas)
    drawDinoSprite(app, canvas)
    drawScore(app, canvas)
    drawGameOver(app, canvas)

def playDinosaurGame():
    runApp(width = 800, height = 600)
    
playDinosaurGame()