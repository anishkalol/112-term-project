15112 Spring 2022
Name: Anishka Bompelli
Year: First-Year

<Project Description>
Name of Project: The Dinosaur Game 2.0
The Dinosaur Game 2.0 is a rendition of the original Chrome browser game, 
the Dinosaur Game. This project is a side-scrolling game where the user guides 
a Tyrannosaurus Rex through several obstacles. The T-Rex must avoid falling into 
holes, jump over cacti, and evade flying vultures. The longer the T-Rex survives, the 
greater the score count. If it collides with an enemy or falls down a hole, it’s game over.

<How to run>
Download the zip file, ensure all files are in the same folder, and run 'main.py'. 

<Modules>
Must have the 'random' and 'PIL' modules installed.

<Shortcut commands>
Press 'S' to start the game, 'Space' or 'Up' to jump, and 'R' to restart if the game is over.