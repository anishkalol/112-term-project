from cmu_112_graphics import *
import random
from PIL import Image

##### sources #####
# sprite from: https://www.spriters-resource.com/browser_games/googledinosaurrungame/sheet/78171/

'''
def dinoWalkHelper(app):
    for _ in range(len(app.points)):
        app.dinosaurY = app.points[app.dinosaurX][1]
'''
def drawDinoSprite(app, canvas):
    sprite = app.dinoSprite[app.spriteCounterDino]
    '''
    for i in range(len(app.points)):
        y = app.points[i][1]
    '''  
    canvas.create_image(app.dinosaurX, app.dinosaurY , image = ImageTk.PhotoImage(sprite))
