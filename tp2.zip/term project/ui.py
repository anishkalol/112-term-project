from cmu_112_graphics import *
import random
from PIL import Image

def drawStartGame(app, canvas):
    canvas.create_rectangle(app.width//3, app.height//3, 
                            2 * app.width//3, 2 * app.height//3)
def drawScore(app, canvas):
    canvas.create_text(2.5 * app.width//3, app.height//10, 
                       text = f'Score: {app.score}',
                       fill = 'black', 
                       font = 'Helvetica 18 bold')

def drawGameOver(app, canvas):
    if app.isGameOver:
        canvas.create_rectangle(app.width//3, app.height//3, 
                                2 * app.width//3, 2 * app.height//3, 
                                fill = 'white')
        canvas.create_text(app.width//2, app.height//2,
                        text = 'Game Over!',
                        fill = 'black',
                        font = 'Helvetica 30 bold')
        canvas.create_text(app.width//2, 50 + app.height//2, 
                           text = 'Press R to restart!',
                           fill = 'black',
                           font = 'Helvetica 18 bold')