from cmu_112_graphics import *
import random
from PIL import Image

# imported files
from terrain import *
from dinosaurSprite import *

##### sources #####
# all sprites from: https://www.spriters-resource.com/browser_games/googledinosaurrungame/sheet/78171/
# terrain gen: https://www.cs.cmu.edu/~112/notes/student-tp-guides/Terrain.pdf 
# ^ used to figure out which algo is appropriate for 1d hill gen
#              https://ijcsit.com/docs/Volume%207/vol7issue2/ijcsit20160702114.pdf

def appStarted(app):
    app.height = 600
    app.width = 800
    
    ##### terrain gen #####
    app.iterations = 7
    app.numPoints = 2**(app.iterations + 1)
    app.terrainHeight = 400
    app.randomRange = 100
    app.points = midpointDisplacement(app.iterations, [[0, app.terrainHeight], [app.width, app.terrainHeight]], app.randomRange)
    
    # holes
    app.randomHolePoint = 0

    ##### side scrolling #####
    app.scrollX = 0
    app.timerDelay = 10

    ##### dino sprite #####
    dinoSprite = 'dinosaursprite.png'
    spriteStripDino = app.loadImage(dinoSprite)
    app.dinoSprite = []
    
    for i in range(2):
        # cropping each sprite movement
        sprite = spriteStripDino.crop((i*53, 10, 54 + 45*i, 90))
        app.dinoSprite.append(sprite)
    app.spriteCounterDino = 0

    app.dinosaurX = 100
    app.dinosaurY = app.points[0][1]

    # vars for jump/fall
    app.isJumping = False
    app.numJumps = 0

    ##### cacti #####
    # cactus images
    app.cactus1 = app.loadImage('cactus1.png')
    app.cactus2 = app.loadImage('cactus2.png')
    app.cactus3 = app.loadImage('cactus3.png')
    app.cacti = [app.cactus1, app.cactus2, app.cactus3]
    
    # list of cactus spawn places
    app.cactusMap = [None] * (len(copy.deepcopy(app.points)))
    app.randomIndexCactus = random.randint(0, len(app.points) - 1) # some point on the terrain
    app.randomCactus = random.randint(0, 2) # picks random cactus img
    # picks random coordinates for the cactus to be placed at
    app.cactusCoords = app.points[app.randomIndexCactus] 
    app.placedCactus = app.cacti[app.randomCactus].crop((0, 0, 50, 100))

    ##### bird enemies #####
    birdsSprite = 'birds.png'
    spriteStripBirds = app.loadImage(birdsSprite)
    app.birdsSprite = []
    # list of bird spawn places
    app.birdMap = [None] * (len(copy.deepcopy(app.points)))
    app.randomIndexBirds = random.randint(0, len(app.points) - 1) # some point on the terrain

    # picks random coordinates for the bird to be placed at
    app.birdCoords = app.points[app.randomIndexBirds]
    app.birdCoords[1] += 70 # float the bird in the air
    
    # sprite
    for i in range(2):
        sprite = spriteStripBirds.crop((7+85*i, 10, 107*i + 100, 100))
        app.birdsSprite.append(sprite)
    app.spriteCounterBirds = 0


def placeCactus(app): # check if cactus can be placed
    if (app.cactusMap[app.randomIndexCactus] == None and 
        app.birdMap[app.randomIndexCactus] == None):
        app.cactusMap[app.randomIndexCactus] = app.placedCactus

def placeBirds(app): # check if bird can be placed
    if (app.birdMap[app.randomIndexBirds] == None and 
        app.cactusMap[app.randomIndexBirds] == None):
        app.birdMap[app.randomIndexBirds] = app.birdsSprite

def timerFired(app):
    # dino running movement
    if app.isJumping == False:
        app.spriteCounterDino = (1 + app.spriteCounterDino) % len(app.dinoSprite)

    # bird flying movement
    app.spriteCounterBirds = (1 + app.spriteCounterBirds) % len(app.birdsSprite)

    app.scrollX += 5

    # generating infinite terrain
    if app.scrollX % app.width == app.width // 8:
        x0 = app.points[-1][0] + 1
        x1 = app.points[-1][0] + app.width + 1
        app.points += midpointDisplacement(app.iterations, [[x0, app.terrainHeight], [x1, app.terrainHeight]], app.randomRange)
        
        # making holes
        app.randomHolePoint = random.randint(app.width//2, len(app.points) - 20)
        for i in range(app.randomHolePoint, app.randomHolePoint + 20):
            app.points[i][1] = 700

    # slicing off points that are already drawn
    # and have moved off the canvas
    if len(app.points) > app.numPoints:
        for i in range(app.numPoints):
            app.points.pop(i)

    # walking on terrain
    '''
    for i in range(len(app.points) - 1):
        if app.dinosaurX == app.points[i][0]:
            app.dinosaurY = app.points[i][1]
    '''

    # jump/fall movement
    if app.isJumping == True:
        if app.numJumps < 6:
            app.dinosaurY -= 15
            app.numJumps += 1
        elif 12 > app.numJumps >= 6:
            app.dinosaurY += 15
            app.numJumps += 1
        if app.numJumps == 12 and app.dinosaurY == app.terrainHeight:
            app.isJumping = False
            app.numJumps = 0
    
'''
def dinoWalk(app):
    dinoWalkHelper(app) 
'''
def keyPressed(app, event):
    if event.key == "Space" or event.key == "Up":
        if app.isJumping == False:
            app.isJumping = True


# draws bird enemies
def drawBirdsSprite(app, canvas):
    sprite = app.birdsSprite[app.spriteCounterBirds]
    x = app.birdCoords[0]
    y = app.birdCoords[1]

    canvas.create_image(x, y-100, image = ImageTk.PhotoImage(sprite))

# draws cactus enemies
def drawCactus(app, canvas):
    x = app.cactusCoords[0]
    y = app.cactusCoords[1]

    canvas.create_image(x, y, image = ImageTk.PhotoImage(app.placedCactus))

def redrawAll(app, canvas):
    drawTerrain(app, canvas)
    drawDinoSprite(app, canvas)
    #drawCactus(app, canvas)
    #drawBirdsSprite(app, canvas)

def playDinosaurGame():
    runApp(width = 800, height = 600)

playDinosaurGame()